# GenieACS Webportal Admin

Webportal untuk manajemen ONT TR-069 dengan fitur OTP login (Fonnte).

## Fitur

- Login OTP via Fonnte
- Dashboard admin
- Lihat ONT dari MongoDB
- Koneksi ke GenieACS API

## Instalasi

### Backend
```
cd backend
cp .env.example .env
npm install
npm run dev
```

### Frontend
```
cd frontend
npm install
npm run dev
```
